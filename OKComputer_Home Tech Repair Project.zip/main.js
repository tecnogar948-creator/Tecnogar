// Funcionalidad principal del sitio TechHome Pro

// Animaciones al hacer scroll
function initScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    // Observar elementos con animación
    document.querySelectorAll('.animate-on-scroll').forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
}

// Calculadora de presupuesto
function initBudgetCalculator() {
    const services = {
        'internet': { name: 'Instalación de Internet', price: 150 },
        'red-wifi': { name: 'Configuración de Red WiFi', price: 80 },
        'cameras': { name: 'Sistema de Cámaras de Seguridad', price: 300 },
        'alarmas': { name: 'Instalación de Alarmas', price: 200 },
        'portero': { name: 'Portero Inalámbrico', price: 180 },
        'cerradura': { name: 'Cerradura Electrónica', price: 250 },
        'electricidad': { name: 'Instalación Eléctrica', price: 120 },
        'domotica': { name: 'Sistema de Domótica', price: 400 }
    };

    const checkboxes = document.querySelectorAll('.service-checkbox');
    const totalDisplay = document.getElementById('total-price');
    const selectedServices = document.getElementById('selected-services');

    function updateTotal() {
        let total = 0;
        let selected = [];

        checkboxes.forEach(checkbox => {
            if (checkbox.checked) {
                const serviceKey = checkbox.dataset.service;
                const service = services[serviceKey];
                total += service.price;
                selected.push(service.name);
            }
        });

        totalDisplay.textContent = `$${total}`;
        
        if (selected.length > 0) {
            selectedServices.innerHTML = '<h4>Servicios seleccionados:</h4><ul>' + 
                selected.map(s => `<li>${s}</li>`).join('') + 
                '</ul>';
        } else {
            selectedServices.innerHTML = '<p class="text-gray-500">Selecciona los servicios que necesitas</p>';
        }
    }

    checkboxes.forEach(checkbox => {
        checkbox.addEventListener('change', updateTotal);
    });
}

// Formulario de contacto
function initContactForm() {
    const form = document.getElementById('contact-form');
    if (!form) return;

    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Mostrar mensaje de éxito
        const successMessage = document.createElement('div');
        successMessage.className = 'bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mt-4';
        successMessage.innerHTML = '<strong>¡Mensaje enviado!</strong> Te contactaremos pronto.';
        
        form.appendChild(successMessage);
        form.reset();
        
        setTimeout(() => {
            successMessage.remove();
        }, 5000);
    });
}

// Sistema de citas (simulado)
function initAppointmentSystem() {
    const calendar = document.getElementById('appointment-calendar');
    if (!calendar) return;

    // Generar calendario simple
    const today = new Date();
    const currentMonth = today.getMonth();
    const currentYear = today.getFullYear();
    
    // Días disponibles (ejemplo)
    const availableDays = [2, 4, 6, 9, 11, 13, 16, 18, 20, 23, 25, 27, 30];
    
    let calendarHTML = '<div class="calendar-grid grid grid-cols-7 gap-2 mb-4">';
    
    // Encabezados de días
    const dayHeaders = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];
    dayHeaders.forEach(day => {
        calendarHTML += `<div class="text-center font-semibold text-gray-600 p-2">${day}</div>`;
    });
    
    // Días del mes (simplificado)
    for (let i = 1; i <= 30; i++) {
        const isAvailable = availableDays.includes(i);
        const dayClass = isAvailable 
            ? 'bg-blue-100 hover:bg-blue-200 cursor-pointer' 
            : 'bg-gray-100 text-gray-400 cursor-not-allowed';
        
        calendarHTML += `
            <div class="day-cell p-2 text-center rounded ${dayClass}" 
                 data-day="${i}" 
                 ${isAvailable ? 'onclick="selectDay(this)"' : ''}>
                ${i}
            </div>
        `;
    }
    
    calendarHTML += '</div>';
    calendar.innerHTML = calendarHTML;
}

function selectDay(element) {
    // Remover selección previa
    document.querySelectorAll('.day-cell').forEach(cell => {
        cell.classList.remove('bg-blue-500', 'text-white');
    });
    
    // Marcar día seleccionado
    element.classList.add('bg-blue-500', 'text-white');
    
    // Mostrar horarios disponibles
    const timeSlots = document.getElementById('time-slots');
    timeSlots.innerHTML = `
        <h4 class="font-semibold mb-2">Horarios disponibles para el día ${element.dataset.day}:</h4>
        <div class="grid grid-cols-3 gap-2">
            <button class="time-slot p-2 border rounded hover:bg-blue-100" onclick="selectTime(this)">9:00 AM</button>
            <button class="time-slot p-2 border rounded hover:bg-blue-100" onclick="selectTime(this)">11:00 AM</button>
            <button class="time-slot p-2 border rounded hover:bg-blue-100" onclick="selectTime(this)">2:00 PM</button>
            <button class="time-slot p-2 border rounded hover:bg-blue-100" onclick="selectTime(this)">4:00 PM</button>
        </div>
    `;
}

function selectTime(element) {
    document.querySelectorAll('.time-slot').forEach(slot => {
        slot.classList.remove('bg-green-500', 'text-white');
    });
    
    element.classList.add('bg-green-500', 'text-white');
    
    // Mostrar botón de confirmación
    const confirmBtn = document.getElementById('confirm-appointment');
    if (confirmBtn) {
        confirmBtn.style.display = 'block';
    }
}

// Inicializar todo cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', function() {
    initScrollAnimations();
    initBudgetCalculator();
    initContactForm();
    initAppointmentSystem();
    
    // Smooth scrolling para enlaces internos
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
});