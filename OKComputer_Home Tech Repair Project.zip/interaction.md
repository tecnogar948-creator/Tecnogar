# Interacciones del Sitio Web

## Componentes Interactivos Principales

### 1. Calculadora de Presupuesto
- Formulario dinámico donde los usuarios pueden seleccionar servicios
- Cálculo automático del presupuesto estimado
- Visualización en tiempo real del costo total
- Posibilidad de enviar la cotización por email

### 2. Sistema de Citas Online
- Calendario interactivo para seleccionar fecha y hora
- Formulario de registro de datos del cliente
- Confirmación automática de citas
- Notificaciones por email

### 3. Galería de Proyectos
- Carrusel de imágenes de trabajos realizados
- Filtros por tipo de servicio
- Modal con detalles de cada proyecto
- Testimonios de clientes

### 4. Chat de Soporte
- Widget de chat flotante para consultas rápidas
- Respuestas automáticas a preguntas frecuentes
- Formulario de contacto alternativo

## Funcionalidades Adicionales

- Animaciones al hacer scroll
- Efectos hover en servicios
- Menú de navegación responsive
- Formulario de contacto con validación
- Integración con WhatsApp para consultas directas