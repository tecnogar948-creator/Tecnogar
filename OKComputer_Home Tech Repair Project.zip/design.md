# Guía de Diseño - TechHome Pro

## Filosofía de Diseño

**Concepto:** Tecnología confiable y accesible para cada hogar
**Enfoque:** Profesionalismo técnico con calidez humana
**Objetivo:** Transmitir seguridad, confianza y expertise tecnológica

## Paleta de Colores

### Colores Principales
- **Azul Tecnológico:** #2563EB (confianza, profesionalismo)
- **Gris Oscuro:** #1F2937 (estabilidad, tecnología)
- **Blanco:** #FFFFFF (limpieza, modernidad)

### Colores Secundarios
- **Azul Claro:** #3B82F6 (innovación)
- **Gris Claro:** #F3F4F6 (fondo, neutralidad)
- **Verde Éxito:** #10B981 (confirmaciones, estados positivos)
- **Naranja Alerta:** #F59E0B (llamadas a la acción)

## Tipografía

### Fuente Principal (Encabezados)
- **Inter:** Sans-serif moderna y legible
- Peso: 600-700 para encabezados
- Tamaño: 2.5rem - 4rem para títulos principales

### Fuente Secundaria (Cuerpo)
- **Inter:** Misma familia para consistencia
- Peso: 400-500 para texto normal
- Tamaño: 1rem - 1.125rem para párrafos

## Estilo Visual

### Elementos de Diseño
- **Geometría:** Formas rectangulares y cuadradas que evocan estabilidad técnica
- **Líneas:** Limpias y precisas, reflejando precisión técnica
- **Espaciado:** Generoso para crear sensación de profesionalismo
- **Sombras:** Suaves para dar profundidad sin ser agresivo

### Iconografía
- Iconos de línea delgada y consistente
- Estilo minimalista y técnico
- Colores en la paleta principal

## Efectos Visuales

### Animaciones
- **Scroll suave:** Transiciones elegantes al hacer scroll
- **Hover effects:** Cambios sutiles en botones y tarjetas
- **Carga progresiva:** Animaciones de entrada para elementos

### Fondos
- **Principal:** Blanco con acentos geométricos en azul
- **Secciones:** Alternancia entre blanco y gris claro
- **Efectos:** Gradientes sutiles azul a blanco

## Componentes UI

### Botones
- **Primarios:** Azul tecnológico con hover más oscuro
- **Secundarios:** Borde azul con fondo transparente
- **Éxito:** Verde para acciones confirmadas

### Tarjetas de Servicio
- Fondo blanco con borde gris claro
- Sombra suave para dar profundidad
- Icono en azul tecnológico

### Formularios
- Campos limpios con bordes sutiles
- Validación en verde/naranja
- Diseño responsive y accesible